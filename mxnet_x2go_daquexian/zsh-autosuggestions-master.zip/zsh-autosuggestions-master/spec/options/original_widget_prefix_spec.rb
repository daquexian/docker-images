describe 'an original zle widget' do
  context 'is accessible with the default prefix'

  context 'when ZSH_AUTOSUGGEST_ORIGINAL_WIDGET_PREFIX is set' do
    it 'is accessible with the specified prefix'
  end
end
