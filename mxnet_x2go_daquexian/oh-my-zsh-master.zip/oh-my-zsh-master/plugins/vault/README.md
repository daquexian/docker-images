## Vault (https://www.vaultproject.io) autocomplete plugin

- Adds autocomplete options for all vault commands.

####Show help for all commands
![General Help](https://i.imgur.com/yv5Db1r.png "Help for all commands")


####Create new Vault token
![Create token](https://i.imgur.com/xMegNgh.png "Create token")


####Enable audit backends
![Audit backends](https://i.imgur.com/fKLeiSF.png "Audit backends")



Crafted with <3 by Valentin Bud ([@valentinbud](https://twitter.com/valentinbud))
